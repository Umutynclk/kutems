# KUTEMS Antigravity aktarım paketi

Antigravity'ye önce `ANTIGRAVITY_PROMPT_TR.md` içeriğini prompt olarak verin. Bu klasördeki dosyaları proje çalışma alanına ekleyin.

- `KUTEMS_Spring_Calculator_WEB_v1_13.html`: ana ve çalışan program (gömülü logo, veriler, fiyat kitabı dahil).
- `YAY ÖRNEKLERİ.docx`: referans SpringForce ekran görüntüleri.
- `low headroom.JPG`, `standard yatakalama.JPG`: karşılaştırma görüntüleri.
- `KUTEMS_FFLogic_arastirma_notlari_v01.md`: tersine mühendislik bağlamı.
- `ANTIGRAVITY_PROMPT_TR.md`: ayrıntılı görev tanımı.

**Ayrı isteğe bağlı kaynak:** `flexi program.zip` (179 MB) orijinal legacy arşividir; bu küçük pakete eklenmedi. Kaynak incelemesi gerekiyorsa ayrıca verin. Üçüncü taraf yazılımın lisans ve kullanım haklarını kontrol edin; orijinal kurulum dosyalarını halka açık projeye koymayın.

Başlangıç hedefi: v1.13'ü birebir koruyan, test edilmiş, yayınlanabilir web sürümü. Hesap formüllerini değiştirmeyin.
