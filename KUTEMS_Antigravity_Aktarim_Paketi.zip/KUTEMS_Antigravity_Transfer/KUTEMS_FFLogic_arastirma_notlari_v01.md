# KUTEMS yay hesaplama motoru — FF‑Logic tersine mühendislik notları

## 1. Ana bulgular

Yüklenen eski FlexiForce FF‑Logic / FF2000 paketi gerçek bir hesap motoru ve veri tabanı içeriyor. EXE içinde `BerekenVeer`, `BerekenKabelTrommel`, `BepaalKabelTrommelEnVeer`, `SelectVerenVoorSelectie`, `RondVeerlengteAf`, `KabelTrommelSlagen`, `VeerLengte`, `VeerLengteGespannen`, `pdblMomentPerVeer`, `AantalWindingen` gibi isimler bulunuyor.

MDB'den çıkarılan kritik tablolar:

- `Deuren`: panel/kapı tipi ve `GewichtPM2` (kg/m²)
- `Kabeltrommels`: tambur tipi, max kg/yükseklik/high‑lift, etkin moment kolları, çevre ve detail table numarası
- `Kabeltrommeldetails`: lift–moment kolu (`Multiplier`)–devir (`Revolutions`) eğrileri
- `Veren`: tel çapı, nominal iç çap, `VeerConstante`, birim ağırlık
- `VeerDetails`: 10k/15k/25k/50k çevrim için izin verilen moment
- `Veerverdeling`: yay sayısına göre sağ/sol dağılım

## 2. Kapı ağırlığı

Program veritabanında doğrudan kg/m² kullanıyor. Örneğin `DE19` 10.00 kg/m². Dolayısıyla:

`m = genişlik(m) × yükseklik(m) × kg/m²`

5000×5000 mm × 10 kg/m² = 250 kg.
6000×5000 mm × 10 kg/m² = 300 kg.

EXE ayrıca `GewichtExclusief`, `GewichtInclusief`, `GewichtHorizontaal`, `GewichtOverig`, `VerstijverGewicht`, `ExtraLoopdeurGewicht` gibi ilave ağırlık alanları içeriyor.

## 3. Tambur fiziği

Kapalı kapıdaki dengeleme momentinin temel bağıntısı:

`M = m × g × r_eff`

Burada `r_eff`, kablonun tamburdan ayrıldığı etkin moment koludur. FF‑Logic veritabanı bunu doğrudan saklıyor veya HL/VL için tablo üzerinden değişken olarak veriyor.

Örnek legacy FF‑NL‑32:
- max kapı: 700 kg
- max yükseklik: 10,000 mm
- high moment arm: 109.537 mm
- flat moment arm: 104.775 mm
- flat circumference: 658.368 mm

Güncel FlexiForce drum datasında FFNL32 için yaklaşık 108.90 mm high moment arm, 104.10 mm flat moment arm ve 654 mm flat circumference veriliyor. Bu, eski FF‑Logic geometrisinin bugünkü ürüne çok yakın olduğunu gösteriyor.

HL drum detail tablolarında `Lift`, `Multiplier`, `Revolutions` bulunuyor. Örneğin FF‑HL‑164 detail table 3, lift büyüdükçe moment kolunu yaklaşık 86.6 mm'den 136.7 mm'ye ve spiral devir sayısını ~0.28'den ~6.00'a çıkarıyor.

## 4. Yay sabiti — önemli tersine mühendislik sonucu

`Veren.VeerConstante` değerleri şu fizik bağıntısıyla neredeyse birebir örtüşüyor:

`C = E × π × d^4 / (32 × Dm)`

- `d`: tel çapı (mm)
- `Dm`: ortalama sarım çapı = iç çap + tel çapı
- `E`: elastisite modülü

40 legacy yay satırından geri hesaplanan E ortalama ~207 GPa. Bu spring steel için fiziksel olarak anlamlı bir değerdir. Dolayısıyla `VeerConstante` gerçek yay rijitliği hesabının ön-katsayısıdır.

Yay başına gereken kapalı moment `M_s` ve kapalı sarım turu `n` bilindiğinde yaklaşık aktif sarım:

`N_active = VeerConstante × n / M_s`

Aktif gövde boyu:

`L_active = N_active × d`

## 5. Çevrim ömrü seçimi

`VeerDetails` her yay geometrisi için 10k / 15k / 25k / 50k moment limitlerini saklıyor. Bu limitler, aynı tel çapında hedef ömür arttıkça düşüyor. Seçim mantığı:

1. Kapı ve tamburdan gereken momenti hesapla.
2. Yay adedine böl.
3. Hedef çevrim sütununu seç.
4. `Moment_cycle >= M_per_spring` şartını sağlayan uygun yayları filtrele.
5. Uygun kombinasyonlar arasında boy/ağırlık/çap optimizasyonu yap.

## 6. Güncel FlexiForce ile doğrulama

Güncel FlexiForce, SpringForce'u kapıyı belirlenen bir life-cycle boyunca dengeleyecek doğru yayı seçen araç olarak tanımlıyor; yeni hesapların IST tarafından test edildiğini belirtiyor.

Güncel endüstriyel yay aralığı FlexiForce sayfalarında 51, 67, 95 ve 152 mm çaplar; yaklaşık 4.5–11.5 mm tel çapları olarak veriliyor. Legacy FF2000 tablosunda nominal çaplar 2.00, 2.63, 3.75 ve 6.00 inch, yani yaklaşık 51, 67, 95 ve 152 mm. Bu güçlü bir süreklilik göstergesidir.

## 7. v0.1 programında bilinçli olarak açık bırakılan konular

- EXE içindeki `RondVeerlengteAf` üretim boyu yuvarlama kuralı
- active coil ile total coil arasındaki koni/dead-coil ilavesinin tam formülü
- open-door residual/preload turn değerinin farklı lift sistemlerine göre tam FF kuralı
- `VeerDetails.Uitvoering = 0/1/2` sınıflarının kesin malzeme/işlem eşlemesi
- güncel SpringForce'un IST sonrası optimizasyon farkları
- KUTEMS'in kendi tambur geometrileri, kablo çapları ve yay çeliği malzeme sertifikası

Bu nedenle v0.1 Ar-Ge/karşılaştırma sürümüdür; doğrudan seri üretim ölçüsü olarak kullanılmamalıdır.

## 8. KUTEMS için önerilen üretim sürümü mimarisi

Girdi: genişlik, yükseklik, panel kg/m² (varsayılan KUTEMS paneli), yataklama tipi, high-lift, çevrim hedefi, şaft, yay adedi tercihi.

Motor: door mass → drum selection → r(x) & revolutions → torque curve → spring candidate filtering → cycle limit → active coils → manufactured length → LH/RH distribution → safety checks.

Çıktı: toplam kg, tambur kodu, kablo boyu, toplam/tek yay momenti, yay tel çapı, iç çap, aktif/toplam sarım, kesim boyu, kurma turu, LH/RH adedi, tahmini yay ağırlığı, çevrim hedefi ve uyarılar.
