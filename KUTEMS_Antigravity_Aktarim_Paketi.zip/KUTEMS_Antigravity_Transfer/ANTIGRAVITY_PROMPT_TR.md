# KUTEMS — Antigravity geliştirme talimatı (v1.13 temel)

Sen kıdemli bir full-stack geliştirici, mekanik hesaplama yazılımı mühendisi ve test otomasyonu uzmanısın. **Mevcut çalışan `KUTEMS_Spring_Calculator_WEB_v1_13.html` dosyasını kaynak gerçek (source of truth) kabul et.** Bu bir sıfırdan hesap motoru yazma işi değildir. Hedef, mevcut doğrulanmış hesap davranışını aynen koruyarak KUTEMS'in web sitesinde yayınlanabilecek bakımı kolay bir uygulamaya dönüştürmektir.

## Sağlanan dosyalar ve öncelik
1. `KUTEMS_Spring_Calculator_WEB_v1_13.html` — EN ÖNEMLİ; çalışan hesaplama, HTML/CSS/JS, tambur/yay verileri, gömülü gerçek KUTEMS logosu, satın alma fiyatları ve kullanıcı arayüzü. Formülleri ve veri dizilerini bu dosyadan doğrudan çıkar; yeniden tahmin etme.
2. `YAY ÖRNEKLERİ.docx` — SpringForce ekran görüntüleri, beklenen sonuçlar ve karşılaştırma testleri. Görselleri de incele; sadece DOCX metin çıkarımına güvenme.
3. `low headroom.JPG` ve `standard yatakalama.JPG` — iki yataklama türünün referans karşılaştırması.
4. `KUTEMS_FFLogic_arastirma_notlari_v01.md` — araştırma bağlamı; erken sürüm notları güncel v1.13 koduyla çelişirse **v1.13 kodu önceliklidir**.
5. Ayrı sağlanacak `flexi program.zip` — eski FF2000/FF-Logic kaynak verisi. **Referans/arşiv olarak kullan**; içindeki eski kurulum dosyalarını çalıştırma, EXE'yi üretim sunucusuna dağıtma. ZIP içindeki MDB tablolarını gerektiğinde kontrollü şekilde analiz et; mevcut doğrulanmış v1.13 formüllerini otomatik olarak eski formüllerle değiştirme.

## Önce yapılacaklar (zorunlu)
- v1.13 HTML dosyasını tam oku; gömülü CSS, JS, logo, fiyat kitabı, drum/spring verileri ve hesap fonksiyonlarının envanterini çıkar.
- Dört sistemin her biri için mevcut davranışı testlerle dondur: Normal Lift, Low Headroom, High Lift, Vertical Lift.
- Testlerde otomatik/manüel tambur, yay adedi 1/2/3/4, yay yönü, halat çapı/uzunluğu, moment, tur, yay çözümleri ve maliyet sıralamasını karşılaştır.
- Mevcut sürümün sonuçlarını referans dosyalardaki örneklerle karşılaştır; uyuşmazlık varsa raporla, kullanıcı onayı olmadan hesap formülünü değiştirme.
- Refactor öncesi ve sonrası aynı girdilerde aynı çıktıları üreten regresyon testleri yaz. Sayısal değerlerde yuvarlama dahil mevcut gösterimi koru.

## İşlevsel gereksinimler — değiştirme
- Uygulama adı: **Seksiyonel Kapı Yay Hesaplama Programı**. Marka KUTEMS; mevcut dosyada gömülü logo kullanılmalı; yeniden çizilmemeli, yeni logo uydurulmamalı.
- Yataklama: Normal Lift, Low Headroom, High Lift, Vertical Lift. Her sistem ayrı hesap yolu. Low Headroom kesinlikle Vertical Lift ile aynı hesap olmamalı.
- Kullanıcı girdileri: yataklama, kapı genişliği (mm), kapı yüksekliği (mm), High Lift için yükselme (mm), panel ağırlığı (kg/m²), yay adedi 1–4, tambur (otomatik veya manuel).
- Kullanıcı arayüzünde **alt panel yükseliği** ve **menteşeli bölüm adedi** alanları OLMAMALI.
- Ağırlık = genişlik(mm) × yükseklik(mm) × kg/m² / 1.000.000.
- High Lift > kapı yüksekliği olduğunda hesaplama engellenecek, açık Türkçe hata gösterilecek. Örnek H=3000, HL=3001: hesaplama YOK; H=3000, HL=3000: mevcut v1.13 davranışı korunacak.
- Tambur varsayılan otomatik seçilecek; manuel listede yalnızca seçili yataklama, kapı ölçüsü, ağırlık, halat çapı ve tambur limitlerine uyan seçenekler bulunacak. Manuel seçim tüm bağlı sonuçları yeniden hesaplayacak. Uygun değilse kullanıcı bilgilendirilecek.
- Kullanıcıya gösterilen tambur kodları **KUT** ile başlayacak: FFNL18 → KUTNL18, FFHL120 → KUTHL120, FFVL18 → KUTVL18 vb. İç veritabanındaki eski FF anahtarları teknik olarak gerekiyorsa korunabilir, ancak arayüzde FF gösterilmemeli. KUT kodlarını gerçek KUTEMS ürünleriyle eşleştirmeden yeni teknik değer uydurma.
- Yay adedi ve etiketler:
  * 1: SAĞ YAY
  * 2: SAĞ YAY, SOL YAY
  * 3: SAĞ YAY, SOL 1 YAY, SOL 2 YAY
  * 4: SAĞ 1 YAY, SAĞ 2 YAY, SOL 1 YAY, SOL 2 YAY
  Her çözüm alternatifi için seçilen yaylar aynı alternatif bloğunda yan yana (mobilde duyarlı) gösterilsin. Sayılar, fiziksel yönler ve çözüm başına yay sayısı korunmalı.
- Yay alternatiflerini v1.13 içindeki `springCostEUR` fiyat kitabına göre artan **oransal maliyet** sırasına koy: fiyat/stok boyu × hesaplanan boy. Fiyatı son kullanıcıya gösterme. Eşitlikte mevcut sıralama korunmalı. Fiyatı olmayan yayı keyfî biçimde en ucuz sayma; eksik fiyat durumunu yöneticiye bildir.
- Sonuçlar: kapı ağırlığı, seçilen KUT tamburu, yay turu, moment/yay, toplam yay rijitliği, halat çapı, halat uzunluğu (mm), uygun yayların tel çapı, iç çapı, boyu, yay rijitliği, momenti, tahmini çevrim. Mevcut gösterim/yuvarlama esas alınmalı.
- Kullanıcıya gösterilmeyecek eski bloklar: 'ZIP motoru aktif' bilgi satırı, en alttaki mavi teknik FF tambur/trace alanı, sarı eski FF2000 çevrim açıklama bloğu. Ancak iç hesaplama, debug logları ve mühendislik uyarıları yok edilmesin; gerekirse yönetici/test görünümünde tutulabilir.
- 'HESAPLA', 'TEMİZLE', 'YAZDIR / PDF' işlevleri çalışmalı. Yazdırma için tarayıcı yazdır/PDF yeterlidir; yeni PDF üretim modülü ancak ayrı onayla eklensin.

## Mühendislik ve güvenlik
- Yaylar yüksek enerji depolayan mekanik bileşenlerdir. Bu bir tasarım destek aracıdır. Doğrulanmamış parametrelerle otomatik üretim/sipariş onayı verme.
- FF2000 tarihî verileri ile güncel SpringForce değerleri arasında fark olabilir. Özellikle çevrim ömrü ve üretim boyu varsayımlarını kesin doğrulanmış gibi sunma.
- Kod ve sonuçlarda kullanılan birimleri açık tanımla: mm, kg, Nm, Nmm/turn, tur, EUR. Girdi sınırları ve NaN/sonsuz/sıfır/negatif kontrollerini ekle; sonuçları bozacak sessiz varsayımlar yapma.
- Yalnızca görsel isimleri değiştirmek için fiziksel tambur katsayılarını değiştirme.

## Teknik teslimat
- İlk teslimatta çalışan **offline/tek dosya HTML** sürümünü mutlaka muhafaza et; bu geri dönüş noktasıdır.
- Ardından kodu okunabilir modüllere ayır: `data/`, `engine/`, `ui/`, `tests/`, `assets/` gibi. Mimari seçimini ve nedenini açıkla. Kullanıcı istemeden sunucu, veritabanı, hesap üyeliği, e-ticaret veya yeni framework zorunluluğu ekleme.
- Web sitesine kurulum için statik hosting seçeneği, örnek dizin yolu `/spring-calculator/`, iframe seçeneği ve sitenin menüsünden doğrudan açılma seçeneği sun. `www.kutems.tr` gerçek ortamına erişimin yoksa yayın yapmış gibi davranma.
- Responsive masaüstü/tablet/telefon tasarımını koru. KUTEMS logosunu görsel oranını bozmadan kullan.
- Geliştirme sürecinde Git commit'leri ve değişiklik günlüğü tut. Kullanıcı onayı olmadan hesap motoru ve satın alma fiyatlarını değiştirme.
- Teslim et: çalışan kaynak kodu, build çıktısı, testler ve test raporu, kurulum README'si, önce/sonra davranış karşılaştırması, varsa bilinmeyenler listesi.

## Doğrulama vakaları
- Normal Lift: W=6000, H=5000, 10 kg/m², 2 yay → ağırlık 300 kg; referans tambur FFNL18'in kullanıcıya görünen adı KUTNL18; yaklaşık 12.8 tur, 110 Nm/yay (diğer ayrıntıları DOCX ve v1.13 ile karşılaştır).
- High Lift: W=6000, H=5000, HL=3000, 10 kg/m², 2 yay → ağırlık 300 kg; KUTHL120; referans yaklaşık 15.3 tur, 170 Nm/yay, 4 mm halat, 9841 mm halat boyu; yay örnekleri 10.5×152×1450 ve 11×152×1830. **v1.13 koduyla kıyasla; bunları özel durum sabiti olarak kodlama.**
- Low Headroom: W=4000, H=3000, 10 kg/m², 2 yay → ağırlık 120 kg; referans yaklaşık 10.0 tur, 34 Nm/yay, 3 mm halat, 7962 mm halat boyu; referans yaylar 6×51×850, 6.5×67×970 vb.
- Yay adedi 1,2,3,4 için hem moment bölüşümü hem etiketler ve her alternatifteki gösterilen yay sayısı kontrol edilsin.
- HL=H+1 engelleme, uygun olmayan tamburun listelenmemesi, manuel tambur değişince tekrar hesap, fiyat sıralaması ve mobil yerleşim ayrı testler olsun.

## Çalışma disiplini
İlk aşamada analiz ve test raporu hazırla. Çalışan uygulamayı bozma. Önce mevcut davranışı göster, sonra refactor et. Her aşamada değişen dosyaları ve nedenini belirt. Eksik veya belirsiz bilgileri tahminle doldurma. Hesap değişikliği gerektiren uyuşmazlıkta kullanıcıya sor.
